import React from 'react'

function UsersProfiles() {
    return (
        <div>
            <h1>USER PROFILES</h1>
        </div>
    )
}

export default UsersProfiles